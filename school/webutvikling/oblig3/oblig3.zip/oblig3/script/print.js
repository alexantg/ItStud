

window.onload= function (){

    var btn=document.getElementById("print");

    btn.onclick=this.skrivUt;

}


    function skrivUt () {
        window.print();
}

